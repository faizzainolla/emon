<div class="span12">      		
	      		
	      		<div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-print"></i>
	      				<h3>Laporan Monitoring</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
					<select class=" span3 populate placeholder select" name="wilayah" required='' id="cwil" onchange="lodsys()">
									<option value="">-- Pilih Wilayah --</option>
								<?php foreach($wilayah as $row){ ?>
									<option value="<?php echo $row['kd_wilayah'];?>"><?php echo $row['nm_wilayah'];?></option>
									
								<?php }
									?>
					</select>&nbsp;&nbsp;&nbsp;  

						<select class=" span3 populate placeholder select" name="sistem" required='' style="margin-left:10px" 
								placeholder='Pilih System' id="csystem">
						</select>&nbsp;&nbsp;

					<button type="submit" class="btn btn-xs  btn-default" name="Filter" onclick="v_lap_monitoring()">
								<span>&nbsp;<i class="icon-search"></i>&nbsp;&nbsp;</span>
								Filter	
					</button>
					<br>
					<hr/>
					<div id='tabeldata' >
					</div><!-- tabeldata view -->


					</div><!-- /widget content -->
				</div><!-- /widget -->
</div>
					
				
				

			

