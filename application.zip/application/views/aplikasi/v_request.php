<div class="span12">   
	<div class="widget ">
			<div class="widget-header">
				<i class="icon-list"></i>
				<h3>Data Request</h3>
			</div> <!-- /widget-header -->
					
			<div class="widget-content">
			<table style='font-size:11px;' class='table table-bordered table-striped table-hover table-heading table-datatable' id='datatable-1'>
         	  <thead style="background-color: #e5e5e5;">
	            <tr>
	              <th>Nama Daerah</th>
	              <th>Nama Sistem</th>
	              <th>Tanggal diterima</th>
	              <th>Jenis Data</th>
	              <th>Kapasitas</th>
	              <th width="10px">Status</th>
	              <th>Keterangan</th>
	              <th> Detail</th>
	              
	            </tr>
          	   </thead>
          	   <tbody id="tbtrack"></tbody>
          	</table>
          	   <br>
          	   <small>* Keterangan : 
          	   <i class='icon-exclamation-sign ' style='color:red;font-size:14px'></i> Belum dikirim |
          	   <i class='icon-plus-sign' style='color:green;font-size:14px'></i> Sudah dikirim 
          	   </small><br>
          	   <small>* Default refresh otomatis setiap 60 detik..</small><br>
			</div>
	</div>
</div>             