<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if($page){
 $this->load->view($page);
}