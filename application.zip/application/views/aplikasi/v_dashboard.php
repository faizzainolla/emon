
	    <div class="span12">
		
          <div class="widget">
            <div class="widget-header"> <i class="icon-bookmark"></i>
              <h3>Shortcuts</h3>
            </div>
            <!-- /widget-header -->
            <div class="widget-content">
              <div class="shortcuts">
              <a href="<?php echo base_url();?>app/page_tracking_monitor" class="shortcut"><i class="shortcut-icon icon-random" style='color:#EE82EE;' ></i>
              <span class="shortcut-label">Tracking Monitoring</span> </a>
              <a href="<?php echo base_url();?>app/page_cr" class="shortcut"> <i class="shortcut-icon icon-bullhorn"  style='color:#FFA500;'></i>
              <span class="shortcut-label">Change Request</span> </a>
              <a href="<?php echo base_url();?>app/chpass" class="shortcut"><i class="shortcut-icon icon-lock"  style='color:#DAA520;'></i>
              <span class="shortcut-label">Set password</span> </a>
              <a href="<?php echo base_url();?>app/logout" class="shortcut"><i class="shortcut-icon icon-signout"  style='color:#B22222;'></i>
              <span class="shortcut-label">Logout</span> </a>
              <!-- /shortcuts --> 
            </div>
            <!-- /widget-content --> 
          </div>
          </div>
          <!-- /widget -->
        </div>
        <!-- /span3 -->
			