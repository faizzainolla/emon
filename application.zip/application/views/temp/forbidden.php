<div class="span12">
			
			<div class="error-container">
				
				<h2>Forbidden Page</h2>
			<h3>Oops, Administrator authority</h3>
			<img src="<?php echo base_url();?>assets/img/frbddn.png" alt="" width="100px" />
				
				<div class="error-actions">
					<a href="<?php echo base_url();?>app" class="btn btn-large btn-primary">
						<i class="icon-chevron-left"></i>
						&nbsp;
						Back to Dashboard						
					</a>
					
					
					
				</div> <!-- /error-actions -->
							
			</div> <!-- /error-container -->			
			
</div> <!-- /span12 -->
