<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="utf-8">
   <title><?php echo $title;?></title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo base_url();?>assets/css/logo.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/pages/dashboard.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/plugins/editable/css/bootstrap-editable.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/plugins/fancybox/jquery.fancybox.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/plugins/select2/select2.css" rel="stylesheet">
	<link rel="icon" type="image/png" href="<?php echo base_url();?>assets/img/msm.png" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/summernote/summernote.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/summernote/summernote-bs3.css">
	
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-1.8.0.min.js"></script>

  </head>
		
<body>

<!--Start Header-->