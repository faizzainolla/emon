<div class="span12">      		
	      		
	      		<div class="widget ">
	      			
	      			<div class="widget-header">
	      				<i class="icon-edit"></i>
	      				<h3>Ganti Password</h3>
	  				</div> <!-- /widget-header -->
					
					<div class="widget-content">
						<?php echo $this->session->flashdata('notif')?>
				<form class="form-horizontal"  method="post" action="<?php echo base_url();?>app/a_chpass" id='chpass'>


					<div class="control-group">											
						<label class="control-label">Password Lama </label>
						<div class="controls">
							<input type="password" class="form-control" name="passold">
						</div> <!-- /controls -->				
					</div> <!-- /control-group -->

					<div class="control-group">											
						<label class="control-label">Password Baru</label>
						<div class="controls">
							<input type="password" class="form-control" name="passnew">
						</div> <!-- /controls -->				
					</div> <!-- /control-group -->


					<div class="control-group">			
																
						<label class="control-label">Confrimasi Password Baru </label>
						<div class="controls">
							<input type="password" class="form-control" name="vpassnew">
						</div> <!-- /controls -->				
					</div> <!-- /control-group -->
					
					
				<div class="form-actions">
							<button type="submit" class="btn btn-primary btn-label-left" name="submit">
							<span><i class="icon-save"> Simpan</i></span>
							
							</button>
							<button type="reset" class="btn btn-danger btn-label-left">
							<span><i class="icon-ban-circle"> Cancel</i></span>
								
							</button>
				</div>
	
				</form>
		
					</div>
				</div>
</div>

			